import { Test, TestingModule } from '@nestjs/testing';
import { AppController } from './app.controller';
import { AppService } from './app.service';

describe('AppController', () => {
  let appController: AppController;
  let appService: AppService;

  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
      controllers: [AppController],
      providers: [AppService],
    }).compile();

    appController = app.get<AppController>(AppController);
    appService = app.get<AppService>(AppService);
  });

  describe('getPeople', () => {
    it('should return a string with people information', async () => {
      const mockId = 1;
      const mockPeopleInfo = 'Mock People Info';
      jest
        .spyOn(appService, 'getPeopleFromSWApi')
        .mockResolvedValue(mockPeopleInfo);

      const result = await appController.getPeople(mockId);

      expect(result).toBe(mockPeopleInfo);
    });
  });

  // You can write similar tests for other methods like getFilms, getPlanets, etc.
});
