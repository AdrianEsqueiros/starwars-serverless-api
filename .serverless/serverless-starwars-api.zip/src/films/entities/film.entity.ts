export class Film {
  título: string;
  episode_id: number;
  opening_crawl: string;
  director: string;
  productora: string;
  fecha_de_lanzamiento: string;
  caracteres: [];
  planetas: [];
  naves_estelares: [];
  vehículos: [];
  especie: [];
}
