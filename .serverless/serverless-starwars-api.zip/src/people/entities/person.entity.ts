export class Person {
  nombre: string;
  altura: number;
  masa: number;
  color_pelo: string;
  color_piel: string;
  color_ojos: string;
  año_nacimiento: string;
  género: string;
  mundo_natal: string;
  películas: [];
  especie: [];
  vehículos: [];
  naves_estelares: [];
}
